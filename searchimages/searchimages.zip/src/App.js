import React from "react";
import Snapshot from "./components/snapshot";

function App() {
  return (
    <>
      <Snapshot/>
    </>
  );
}

export default App;
